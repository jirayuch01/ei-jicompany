angular.module('emailController', ['userServices'])
.controller('emailCtrl', function($routeParams, User, $timeout, $location) {
    app = this;
    User.activateAccount($routeParams.token).then(function(data) {
        app.errorMsg = false; 
        if (data.data.success) {
            app.successMsg = data.data.message + '...Redirecting'; /
            $timeout(function() {
                $location.path('/login');
            }, 2000);
        } else {
            app.errorMsg = data.data.message + '...Redirecting'; // If not successful, grab message from JSON object and redirect to login page
            $timeout(function() {
                $location.path('/login');
            }, 2000);
        }
    });
})

.controller('resendCtrl', function(User, $scope) {
    app = this;
    app.checkCredentials = function(loginData, valid) {
        if (valid) {
            app.disabled = true; // Disable the form when user submits to prevent multiple requests to server
            app.errorMsg = false; 
            User.checkCredentials(app.loginData).then(function(data) {
                if (data.data.success) {
                    User.resendLink(app.loginData).then(function(data) {
                        if (data.data.success) {
                            $scope.alert = 'alert alert-success'; // Set error message ng-class
                            app.successMsg = data.data.message; // If successful, grab message from JSON object
                        } else {
                            $scope.alert = 'alert alert-danger'; // Set error message ng-class
                            app.errorMsg = data.data.message; // If not successful, grab message from JSON object
                        }
                    });
                } else {
                    app.disabled = false; // If error occurs, remove disable lock from form
                    $scope.alert = 'alert alert-danger'; // Set error message ng-class
                    app.errorMsg = data.data.message; // If credentials do not match, display error from JSON object
                }
            });
        } else {
            $scope.alert = 'alert alert-danger'; // Set error message ng-class
            app.errorMsg = 'Please ensure form is filled out properly'; // Set form error message
        }

    };
})

.controller('usernameCtrl', function(User, $scope) {
    app = this;
    app.sendUsername = function(userData, valid) {
        app.errorMsg = false; // Clear errorMsg when user submits
        app.loading = true; // Start loading icon while processing
        app.disabled = true;            
        if (valid) {
            User.sendUsername(app.userData.email).then(function(data) {
                app.loading = false; 
                if (data.data.success) {
                    $scope.alert = 'alert alert-success'; // Set success message class
                    app.successMsg = data.data.message; // If success, grab message from JSON object
                } else {
                    app.disabled = false; // Enable form to allow user to retry
                    $scope.alert = 'alert alert-danger'; // Set alert class
                    app.errorMsg = data.data.message; // If error, grab message from JSON object
                }
            });
        } else {
            app.disabled = false; // Enable form to allow user to retry
            app.loading = false; // Stop loading icon
            $scope.alert = 'alert alert-danger'; // Set alert class
            app.errorMsg = 'Please enter a valid e-mail'; // Let user know form is not valid
        }
    };
})

.controller('passwordCtrl', function(User, $scope) {
    app = this;
    app.sendPassword = function(resetData, valid) {
        app.errorMsg = false; // Clear errorMsg
        app.loading = true; // Start loading icon
        app.disabled = true; 
        if (valid) {
            User.sendPassword(app.resetData).then(function(data) {
                app.loading = false; 
                if (data.data.success) {
                    $scope.alert = 'alert alert-success'; // Set success message class
                    app.successMsg = data.data.message; // Grab success message from JSON object
                } else {
                    $scope.alert = 'alert alert-danger'; // Set success message class
                    app.disabled = false; // Enable form to allow user to resubmit
                    app.errorMsg = data.data.message; // Grab error message from JSON object
                }
            });
        } else {
            app.disabled = false; // Enable form to allow user to resubmit
            app.loading = false; // Stop loading icon
            $scope.alert = 'alert alert-danger'; // Set success message class
            app.errorMsg = 'Please enter a valid username'; // Let user know form is not valid
        }
    };
})

.controller('resetCtrl', function(User, $routeParams, $scope, $timeout, $location) {
    app = this;
    app.hide = true; 
    User.resetUser($routeParams.token).then(function(data) {
        if (data.data.success) {
            app.hide = false; // Show form
            $scope.alert = 'alert alert-success'; // Set success message class
            app.successMsg = 'Please enter a new password'; // Let user know they can enter new password
            $scope.username = data.data.user.username; // Save username in scope for use in savePassword() function
        } else {
            $scope.alert = 'alert alert-danger'; // Set success message class
            app.errorMsg = data.data.message; // Grab error message from JSON object
        }
    });

    app.savePassword = function(regData, valid, confirmed) {
        app.errorMsg = false; // Clear errorMsg when user submits
        app.successMsg = false;
        app.disabled = true; // Disable form while processing
        app.loading = true;
        if (valid && confirmed) {
            app.regData.username = $scope.username; 
            User.savePassword(app.regData).then(function(data) {
                app.loading = false;
                if (data.data.success) {
                    $scope.alert = 'alert alert-success'; // Set success message class
                    app.successMsg = data.data.message + '...Redirecting'; 
                    $timeout(function() {
                        $location.path('/login');
                    }, 2000);
                } else {
                    $scope.alert = 'alert alert-danger'; // Set success message class
                    app.disabled = false; // Enable form to allow user to resubmit
                    app.errorMsg = data.data.message; // Grab error message from JSON object
                }
            });
        } else {
            $scope.alert = 'alert alert-danger'; // Set success message class
            app.loading = false; // Stop loading icon
            app.disabled = false; // Enable form to allow user to resubmit
            app.errorMsg = 'Please ensure form is filled out properly'; // Let user know form is not valid
        }
    };
});
